<!DOCTYPE html>
<html>
<head>
	<title>Penjualan Kopi</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<section id="header">
			<div id="tgl-now"></div>
		</section>
		<div class="container">
			<section id="content">
				<div class="col-4s"><input style="height: 100px;font-size: 35px;" type="text" id="nama_kopi" placeholder="Nama Kopi" class="form-control"></div>
				<div class="col-4s"><input style="height: 100px;font-size: 35px;" type="number" id="harga_kopi" placeholder="Harga Kopi" class="form-control"></div>
				<div class="col-4s"><button style="height: 115px;font-size: 35px;" id="simpanKopi" onclick="simpanKopi()" class="form-control btn btn-primary">Simpan</button></div>
				<div class="clearfix"></div><br>
				<div class="col-6">
					<div class="well">
						<table class="trans">
						  <thead>
						  	<tr>
						  	  <th class="text-center">No</th>
						  	  <th class="text-center">Produk</th>
						  	  <th class="text-center">Harga</th>
						  	  <th class="text-center">QTY</th>
						  	  <th class="text-center">Subtotal</th>
						  	  <th class="text-center">Hapus</th>
						  	</tr>
						  </thead>
						  <tbody style="max-height: 200px;overflow: scroll;" id="_list_items">
						  	<tr>
						  		<td colspan="6">
						  			<center><i>Data Belum ada</i></center>
						  		</td>
						  	</tr>
						  	<!-- <tr>
						  	  <td class="text-center">X</td>
						  	  <td class="text-center">Kopi 1</td>
						  	  <td class="text-center">1</td>
						  	  <td class="text-center">120000</td>
						  	</tr>
						  	<tr>
						  	  <td class="text-center">X</td>
						  	  <td class="text-center">Kopi 1</td>
						  	  <td class="text-center">1</td>
						  	  <td class="text-center">120000</td>
						  	</tr>
						  	<tr>
						  	  <td class="text-center">X</td>
						  	  <td class="text-center">Kopi 1</td>
						  	  <td class="text-center">1</td>
						  	  <td class="text-center">120000</td>
						  	</tr>
						  	<tr>
						  	  <td class="text-center">X</td>
						  	  <td class="text-center">Kopi 1</td>
						  	  <td class="text-center">1</td>
						  	  <td class="text-center">120000</td>
						  	</tr>
						  	<tr>
						  	  <td class="text-center">X</td>
						  	  <td class="text-center">Kopi 1</td>
						  	  <td class="text-center">1</td>
						  	  <td class="text-center">120000</td>
						  	</tr>
						  	<tr>
						  	  <td class="text-center">X</td>
						  	  <td class="text-center">Kopi 1</td>
						  	  <td class="text-center">1</td>
						  	  <td class="text-center">120000</td>
						  	</tr> -->
						  </tbody>
						</table>
						<br>
						<table>
							<tr>
								<td>Total Item : <span id="_total_item">0</span></td>
								<td></td>
							</tr>
							<tr>
								<td>
									<table>
										<tr>
											<td style="width: 20%;">Type</td>
											<td>
												<select onchange="tipeDiscount()" id="tipe_discount" class="form-control">
													<option value="">-- Pilih --</option>
													<option value="rp">Rupiah</option>
													<option value="prc">Persen</option>
												</select>
											</td>
										</tr>
										<tr>
											<td style="width: 20%;">Dicount</td>
											<td><input type="number" id="discount" value="0" onkeyup="render_items()" class="form-control"></td>
										</tr>
									</table>
								</td>
								<td><h2>Total : <span id="_total">0</span></h2></td>
							</tr>
						</table>
					</div>
				</div>
				<div class="col-6">
					<div class="well" style="background-color: #000;color: #fff;">
						Menu
					</div>
					<div class="header-menu">
						<div class="col-12" style="background-color: #007fff;" id="tempat-menu">
						</div>
					</div>
				</div>
			</section>
		<section id="footer"></section>
	</div>
</body>
<script type="text/javascript" src="wow.js"></script>
</html>