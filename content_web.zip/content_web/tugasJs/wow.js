var selected_product = [];
var total = 0;
var total_fix = 0;
var kopi = [
  {
      "nama":"Kopi 1",
      "harga":10000,
  },
  {
      "nama":"Kopi 2",
      "harga":20000,
  },
  {
      "nama":"Kopi 3",
      "harga":30000,
  },
  {
      "nama":"Kopi 4",
      "harga":40000,
  },
  {
      "nama":"Kopi 5",
      "harga":50000,
  },
  {
      "nama":"Kopi 6",
      "harga":60000,
  },
  {
      "nama":"Kopi 7",
      "harga":70000,
  },
  {
      "nama":"Kopi 8",
      "harga":80000,
  },
  {
      "nama":"Kopi 9",
      "harga":90000,
  },
];
init();
function init() {
	var tanggal = new Date();
	var jumlah_menu = kopi.length;
	var tempat_menu = document.getElementById("tempat-menu");
	// console.log(jumlah_menu);

	var html = '';
	if (jumlah_menu) {
		for (var i = 0; i < jumlah_menu; i++) {
			// html += "<div class='col-4' onClick='add_temporary_item("+i+","+kopi[i].nama+","+kopi[i].harga+")'>"+kopi[i].nama+"<br>("+convertToRupiah(kopi[i].harga)+")</div>";
			html += "<div class='col-4' onclick='add_temporary_item("+(i+1)+","+'"'+kopi[i].nama+'"'+","+kopi[i].harga+") '>"+kopi[i].nama+"<br>("+convertToRupiah(kopi[i].harga)+")</div>";
		}
	}
	tempat_menu.innerHTML = html;
	document.getElementById("tgl-now").innerHTML = tanggal;
}

function add_temporary_item(id, nama, harga,qty=1){
    var arr_length = selected_product.length;

    var items = {};

    var subtotal = ( parseInt(harga) * parseInt(qty));

    var len = selected_product.length;
    if(len == 0){

        items.id = id;
        items.nama = nama;
        items.harga = harga;
        items.qty = qty;
        items.subtotal = subtotal;

        selected_product.push(items);

    } else {
        var same_items = false;
        for( var i = 0, len = selected_product.length; i < len; i++ ) {
            if( selected_product[i]['id'] === id ) {
                selected_product[i]['qty'] = parseInt(selected_product[i]['qty']) + parseInt(qty);

                var total_bruto = parseInt(selected_product[i]['harga']) * selected_product[i]['qty'];
                
                selected_product[i]['subtotal'] = total_bruto;
                same_items = true;

            }

        }

        if(same_items == false){
            items.id = id;
            items.nama = nama;
            items.harga = harga;
            items.qty = qty;
            items.subtotal = subtotal;

            selected_product.push(items);
        }

    }

    render_items();
}

function render_items(){
    total = 0;
    if(selected_product.length > 0){
        var html_ = '';
        document.getElementById('_list_items').innerHTML = '';
        var no = 1;
        
        selected_product.forEach(function(obj, index){
            html_ += '<tr>';
            html_ += '<td class="text-center">'+no+'</td>';
            html_ += '<td>'+obj.nama+'</td>';
            html_ += '<td class="text-right">'+convertToRupiah(obj.harga)+'</td>';
            html_ += '<td class="text-right">'+obj.qty+'</td>';
            html_ += '<td class="text-right">'+convertToRupiah(obj.subtotal)+'</td>';
            html_ += '<td class="text-center"><button class="_remove" style="cursor:pointer" onclick="delete_items(this)" data-index="'+index+'">x</button></td>';
            html_ += '</tr>';

            no++
            total = total + obj.subtotal;
        });

        var tipe_discount = document.getElementById("tipe_discount").value;
        var val_discount = document.getElementById("discount").value;
        if (tipe_discount) {
        	if (tipe_discount == "rp") {
        		total = total - val_discount;
        	}else{
        		total = total - ((val_discount/100)*total);
        	}
        }
        total_fix = total;

        document.getElementById('_total_item').innerHTML = selected_product.length;
        document.getElementById('_list_items').innerHTML = html_;
        document.getElementById('_total').innerHTML = convertToRupiah(total);

    } else {
        var html_ = '';
        document.getElementById('_total_item').innerHTML = 0;
        document.getElementById('_list_items').innerHTML = '';
        document.getElementById('_total').innerHTML = 0;
    }
}

function delete_items(o){
    var index = o.getAttribute('data-index');
    selected_product.splice(index, 1);
    render_items();
}

function convertToRupiah(angka)
{
	var rupiah = '';		
	var angkarev = angka.toString().split('').reverse().join('');
	for(var i = 0; i < angkarev.length; i++) if(i%3 == 0) rupiah += angkarev.substr(i,3)+'.';
	return 'Rp. '+rupiah.split('',rupiah.length-1).reverse().join('');
}
 
function convertToAngka(rupiah)
{
	return parseInt(rupiah.replace(/,.*|[^0-9]/g, ''), 10);
}

function tipeDiscount() {
	document.getElementById("discount").value = 0;
	render_items();
}

function simpanKopi() {
	var val_namaKopi = document.getElementById("nama_kopi").value;
	var val_hargaKopi = document.getElementById("harga_kopi").value;
	if (!val_namaKopi) {
		alert("Masukkan Nama Kopi !");
		return;
	}
	if (!val_hargaKopi) {
		alert("Masukkan Harga Kopi !");
		return;
	}
	if(isNaN(val_hargaKopi)){
		alert("Masukkan Harga Kopi dengan Angka !");
		return;
	}
	var kopiBaru = {
	    "nama" : val_namaKopi,
	    "harga" : val_hargaKopi
	};
	kopi.push(kopiBaru);
	init();
	emptyForm();
	alert("Berhasil !");
}
function emptyForm() {
	document.getElementById("nama_kopi").value = '';
	document.getElementById("harga_kopi").value = '';
}